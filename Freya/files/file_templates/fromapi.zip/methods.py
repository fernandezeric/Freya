"""
Aquí van los metodos que se necesiten para lograr completar 'configure.py',
toy dudanto de esto porque requiere una major adaptabilidad a la hora de crear archivos
"""
import requests
import io
from Freya.core import utils as u

def metodo_generico ():
    return 1

def metodo_generico_2():
    return 2


