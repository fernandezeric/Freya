"""
In this file you can created methods for 'configure.py'  
"""
import requests
import io
from Freya.core import utils as u

class Methods_NAME():

    def method_NAME():
        return 1

    def method_NAME_2():
        return 2