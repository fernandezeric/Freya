import sys
import importlib
from Freya_alerce.catalogs.core import GetData
class ResourceNAME():
    """
    Parameters
    ----------
    ra : (float) Right ascension
    dec :  (float) Declination
    hms : (string) HH:MM:SS
    radius: (float) Search radius
    format: (string) csv or votable
    """
    def __init__(self,**kwagrs):
        self.ra = kwagrs.get('ra')
        self.dec = kwagrs.get('dec')
        self.hms = kwagrs.get('hms')
        self.radius = kwagrs.get('radius')
        self.format = kwagrs.get('format')
 
    """
    Get the all light curves data from astronomical objects called Freya’s getData method for specific catalog, using degree area.  
    """       
    def get_lc_deg_all(self):
        data_method = GetData(catalog='NAME',ra=self.ra,dec=self.dec,radius=self.radius,format=self.format).get_lc_deg_all()
        return data_method

    """
    Get the one light curve data from astronomical object called Freya’s getData method for specific catalog, using degree area.  
    """
    def get_lc_deg_nearest(self):
        data_method = GetData(catalog='NAME',ra=self.ra,dec=self.dec,radius=self.radius,format=self.format).get_lc_deg_nearest()
        return data_method

    """
    Get the all light curves data from astronomical objects called Freya’s getData method for specific catalog, using hh:mm:ss area.  
    """
    def get_lc_hms_all(self):
        data_method = GetData(catalog='NAME',hms=self.hms,radius=self.radius,format=self.format).get_lc_hms_all()
        return data_method

    """
    Get the one light curve data from astronomical object called Freya’s getData method for specific catalog, using hh:mm:ss area.  
    """
    def get_lc_hms_nearest(self):
        data_method = GetData(catalog='NAME',hms=self.hms,radius=self.radius,format=self.format).get_lc_hms_nearest() 
        return data_method
