"""
MethodsNAME, you can use this method if you do not want overburden configure.py, especially want to use module class to get data, you can replace all script.
"""
import requests
import io
from Freya_alerce.core import utils as u

class MethodsNAME():
    """
    Parameters
    ----------
    ra : (float) Right ascension
    dec :  (float) Declination
    radius: (float) Search radius
    format: (string) csv or votable
    nearest: (bool) Flag to indicate if you get all or one light curve from the object.
    """
    def __init__(self,**kwagrs):
        self.ra = kwagrs.get('ra')
        self.dec = kwagrs.get('dec')
        self.hms = kwagrs.get('hms')
        self.radius = kwagrs.get('radius')
        self.format = kwagrs.get('format')

    def method_NAME():
        return 1

    def method_NAME_2():
        return 2
