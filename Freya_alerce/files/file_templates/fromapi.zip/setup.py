
from setuptools import setup

# pip install -e .
setup(
      name='NAME',
      version='0.1',
      description='Module for Freya',
      url='',
      author='',
      author_email='',
      license='',
      packages=['NAME'],
      zip_safe=False,
      install_requires=['astropy','pandas','requests']
)
