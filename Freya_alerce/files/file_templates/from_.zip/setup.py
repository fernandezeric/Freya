
from setuptools import setup

# pip install .
setup(
      name='NAME',
      version='0.1',
      description='Module for Freya',
      url='',
      author='',
      author_email='',
      license='',
      packages=['NAME'],
      zip_safe=False,
      install_requires=[i.strip() for i in open("requirements.txt").readlines()]
)
